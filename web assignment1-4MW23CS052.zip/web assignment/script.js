$(document).ready(function () {
    console.log("Website Loaded Successfully");
});
